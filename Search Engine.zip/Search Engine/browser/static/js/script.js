$(document).ready(function(){
//ACTIVE BOTTOM BAR START
    $(".bottom-bar li").hover(function(){
        $(this).find(".blank-border").toggleClass("active-blank-border");
        $(this).find(".my-btn1").toggleClass("active-bottom-bar");
    });
//ACTIVE BOTTOM BAR END
//BG AUTO HEIGHT START
    //var buttonwidth = $(".my-btn").width();
    var planetwidth = $(".planet").width();
    var eyewidth = $(".eye").width();
     $(".eye").css("height", eyewidth/2 +4 +"px");
    $(".planet").css("height", planetwidth +"px");
    $(".wrap").css("height", planetwidth +"px");
    $(".clouds").css("height", planetwidth +"px");
    $(".mask").css("height", planetwidth +"px");
    $(".background").css("height", planetwidth +"px");
     //$(".my-btn").css("height", buttonwidth +"px");
    $(window).resize(function(){
        var eyewidth = $(".eye").width();
     var planetwidth = $(".planet").width();
     $(".eye").css("height", eyewidth/2 +4 +"px");
        //$(".my-btn").css("height", buttonwidth +"px");
        $(".planet").css("height", planetwidth +"px");
        $(".wrap").css("height", planetwidth +"px");
    $(".clouds").css("height", planetwidth +"px");
    $(".mask").css("height", planetwidth +"px");
    $(".background").css("height", planetwidth +"px");
    });
//BG AUTO HEIGHT END    
//ACTIVE "li" START
    $(".tabs-li ul li:first-child").addClass("active-tab");
    $(".tabs-li ul li").click(function(){
        $(".tabs-li ul li").removeClass("active-tab");
        $(this).addClass("active-tab");
    });
//ACTIVE "li" END


});