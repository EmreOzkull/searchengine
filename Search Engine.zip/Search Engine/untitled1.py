#web_crawler

import urllib.request

def get_page(url):   
    try:
        page= urllib.request.urlopen(url)
        page=page.read()
        page=str(page)
        
        return page
    except:
        return ""

def get_next_target(page):
    start_link = page.find('<a href=')
    if start_link == -1: 
        return None, 0
    start_quote = page.find('"', start_link)
    end_quote = page.find('"', start_quote + 1)
    url = page[start_quote + 1:end_quote]
    return url, end_quote

def union(p,q):
    for e in q:
        if e not in p:
            p.append(e)


def get_all_links(page):
    links = []
    while True:
        url,endpos = get_next_target(page)
        if url:
            links.append(url)
            page = page[endpos:]
        else:
            break
    return links


def crawl_web(seed): 
    tocrawl = [seed] 
    crawled = [] 
    graph= {}
    index = {}
    stopper=0
    while tocrawl: 
        page = tocrawl.pop()
        if page not in crawled and stopper<=50: 
            content = get_page(page)   
            outlinks = get_all_links(content)
            add_page_to_index(index, page, content)
            graph[page] = outlinks
            union(tocrawl, outlinks)
            crawled.append(page)
            
        stopper+=1
    return index, graph

#build_index


def add_page_to_index(index, url, content): 
    words = content.split()
    for word in words: 
        add_to_index(index, url, word) 

def add_to_index(index, url, keyword): 
    if keyword in index:
        if url not in index[keyword]:
            index[keyword].append(url)
        return
    index[keyword]=[url]
def lookup(index, keyword): 
    if keyword in index:
        
        return index[keyword]
    else:
        return None


#page_rank--------------------------------------------------------------------
    
def compute_ranks(graph):
    d = 0.8 # damping factor
    numloops = 10

    ranks = {}
    npages = len(graph)
    for page in graph:
        ranks[page] = 1.0 / npages

    for i in range(0, numloops):
        newranks = {}
        for page in graph:
            newrank = (1 - d) / npages
            for node in graph:
                if page in graph[node]:
                    newrank = newrank + d * (ranks[node] / len(graph[node]))
            newranks[page] = newrank
        ranks = newranks
    return ranks

def quick_sort(pages,ranks):
    if not pages or len(pages)<= 1:
        return pages
    else:
        pivot=pages[0]
        worse=[]
        better=[]
        for page in pages [1:]:
            if ranks[page]<=pivot:
                worse.append(page)
            else:
                better.append(page)
    print(pivot)
    return quick_sort(better,ranks)+[pivot]+quick_sort(worse,ranks)

    
def ordered_search(index,ranks,keyword):
    pages=lookup(index,keyword)
    return quick_sort(pages,ranks)

def son_bakis(index,ranks,keyword):
    pages=lookup(index,keyword)
    urlu=[]
    quick_sort(pages,ranks)
    for i in pages:
        urlu.append(i)
    
    return urlu

def sonuc():
    adres='https://www.youtube.com/'
    keyword="a"
    index,graph=crawl_web(adres)
    ranks=compute_ranks(graph)
    cikti=ordered_search(index,ranks,keyword)
    return cikti
#index, graph = crawl_web('https://www.youtube.com/')
#ranks = compute_ranks(graph)
#print (lookup(index,"a"))
print(sonuc())